$(function() {
    $('.liang').on({
        mouseover: function() {
            $(this).css('background', 'white')
            $(this).children('ul').css('display', 'block');
        },
        mouseleave: function() {
            $(this).css('background', '')
            $(this).children('ul').css('display', 'none');
        }
    })
    $('.list>li').on({
        mouseover: function() {
            var index = $(this).index();
            $('.hid_box li').eq(index).css('display', 'block');
        },
        mouseleave: function() {
            var index = $(this).index();
            $('.hid_box li').eq(index).css('display', 'none');
        }
    })
    ceX();

    function ceX() {
        var recomTop = $('.banner').offset().top;
        if ($(document).scrollTop() >= recomTop) {
            $('.ce').show();
        } else {
            $('.ce').hide();
        }
    }
    $(window).scroll(function() {
        ceX();
        $('.box_hid').each(function(i, ele) {
            if ($(document).scrollTop() >= $(ele).offset().top) {
                $('.ce li').eq(i).addClass('current').siblings().removeClass('current')
            }
        })


    })
    $('.ce li').on('click', function() {
        var i = $(this).index();
        var current = $('.box_hid').eq(i).offset().top;
        $('body,html').stop().animate({
            scrollTop: current
        })
        $(this).addClass('current').siblings().removeClass('current');
    })



})