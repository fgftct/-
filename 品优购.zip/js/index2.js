//利用load事件来加载完html在执行代码
window.addEventListener('load', function() {
    //1.获取元素
    var btn_l = document.querySelector('.btn_l');
    var btn_r = document.querySelector('.btn_r');
    var foucs_le = document.querySelector('.foucs_le');
    var ul = document.querySelector('.foucs_ul');
    var ol = document.querySelector('.foucs_ol');
    var focusWidth = foucs_le.offsetWidth;
    //2.当鼠标经过focus时就会影藏left right的样式
    foucs_le.addEventListener('mouseenter', function() {
        btn_l.style.display = 'block';
        btn_r.style.display = 'block';
        clearInterval(timer);
        //清楚定时器变量
        // timer = null;
    })
    foucs_le.addEventListener('mouseleave', function() {
            btn_l.style.display = 'none';
            btn_r.style.display = 'none';
            timer = setInterval(function() {
                //手动调用点击事件
                btn_r.click();
            }, 2000);

        })
        //3.动态生成小圆圈  有几张图片，我就生成几个小圆圈
        //找到每一个图片
    for (var i = 0; i < ul.children.length; i++) {
        //创建小li
        var li = document.createElement('li');
        //添加小li
        li.setAttribute('index', i);
        ol.appendChild(li);
        //创建索引
        //4。小圆圈的排他思想 我们可以直接在生成小圆圈的同时直接绑定点击事件
        li.addEventListener('click', function() {

            //先干掉他人
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            this.className = 'current';
            var index = this.getAttribute('index');
            //5.点击小圆点移动图片，这里移动的是ul
            //先设值索引号 ul 的移动距离 小圆圈的索引号 乘以 图片的宽度 注意是负值
            // 当我们点击了某个小li 就要把这个li 的索引号给 num  
            num = index;
            // // 当我们点击了某个小li 就要把这个li 的索引号给 circle  
            circle = index;
            animate(ul, -index * focusWidth);

        })

    }
    ol.children[0].className = 'current';
    //6.克隆第一张图片 clone与appendchild连用
    var clone = ul.children[0].cloneNode(true);
    ul.appendChild(clone);
    //7.点击右侧按钮滚动图片
    var circle = 0;
    var num = 0;
    var flag = true;
    // 右侧按钮
    btn_r.addEventListener('click', function() {
            if (flag) {
                flag = false;
                if (num == ul.children.length - 1) {
                    ul.style.left = 0;
                    num = 0;
                }
                num++;
                animate(ul, -num * focusWidth, function() {
                    flag = true;
                });
                // 8. 点击右侧按钮，小圆圈跟随一起变化 可以再声明一个变量控制小圆圈的播放
                circle++;
                if (circle == ol.children.length) {
                    circle = 0;
                }
                circleChange();
            }
        })
        //左侧按钮
    btn_l.addEventListener('click', function() {
        if (flag) {
            flag = false;
            if (num == 0) {
                num = ul.children.length - 1;
                ul.style.left = -num * focusWidth + 'px';
            }
            num--;
            animate(ul, -num * focusWidth, function() {
                flag = true;
            });
            // 8. 点击右侧按钮，小圆圈跟随一起变化 可以再声明一个变量控制小圆圈的播放
            circle--;
            if (circle < 0) {
                circle = ol.children.length - 1;
            }
            circleChange();
        }
    })

    function circleChange() {
        // 先清除其余小圆圈的current类名
        for (var i = 0; i < ol.children.length; i++) {
            ol.children[i].className = '';
        }
        // 留下当前的小圆圈的current类名
        ol.children[circle].className = 'current';
    }
    var timer = setInterval(function() {
        //手动调用点击事件
        btn_r.click();
    }, 2000);



    var icon = document.querySelectorAll('.icon');
    for (var i = 0; i < icon.length; i++) {
        var widthl = i * 16;
        var heightl = i * 15;
        icon[i].style.backgroundPosition = '-' + widthl + 'px' + '-' + heightl + 'px';
    }


})